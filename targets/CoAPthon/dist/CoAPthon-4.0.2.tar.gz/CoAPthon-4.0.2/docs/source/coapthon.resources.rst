coapthon.resources package
==========================

Submodules
----------

coapthon.resources.resource module
----------------------------------

.. automodule:: coapthon.resources.resource
    :members:
    :show-inheritance:


Module contents
---------------

.. automodule:: coapthon.resources
    :members:
    :show-inheritance:
